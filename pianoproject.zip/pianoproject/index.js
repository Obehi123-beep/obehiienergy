// function legit() {
//     alert('i got clicked')
    
    
//     }

function legit() {

    var piano = this.innerHTML;


if(piano == 'c'){
    var audio = new Audio('sounds/1.mp3');
        audio.play();  
}else if(piano == 'd'){
    var audio = new Audio('sounds/2.mp3');
        audio.play();
}else if(piano == 'e'){
    var audio = new Audio('sounds/3.mp3');
        audio.play();
}else if(piano == 'f'){
    var audio = new Audio('sounds/4.mp3');
        audio.play();
}else if(piano == 'g'){
    var audio = new Audio('sounds/5.mp3');
        audio.play();
}else if(piano == 'a'){
    var audio = new Audio('sounds/6.mp3');
        audio.play();
}else if(piano == 'b'){
    var audio = new Audio('sounds/7.mp3');
        audio.play();
}else{
    alert('not applicable')
}
}
var mainkeyWord = document.querySelectorAll('.key').length;
// alert(mainkeyWord)



for (let i = 0; i < mainkeyWord; i++) {
    document.querySelectorAll('.key')[i].addEventListener('click', legit);
    
}

document.querySelectorAll('.key').forEach(key => {
    key.style.color = '#ffffff';
  });
  












